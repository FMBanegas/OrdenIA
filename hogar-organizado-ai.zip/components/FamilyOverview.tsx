
import React from 'react';
import { FamilyMember } from '../types';
import { StarIcon } from './icons';

interface FamilyOverviewProps {
  familyMembers: FamilyMember[];
}

const FamilyOverview: React.FC<FamilyOverviewProps> = ({ familyMembers }) => {
  return (
    <div className="mb-8 p-6 bg-white rounded-xl shadow-lg">
      <h2 className="text-xl font-bold mb-4 text-gray-700">Panel Familiar</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {familyMembers.map(member => (
          <div key={member.id} className="flex flex-col items-center p-3 bg-slate-50 rounded-lg border border-slate-200">
            <img src={member.avatar} alt={member.name} className="w-16 h-16 rounded-full mb-2 border-4 border-white shadow-sm" />
            <h3 className="font-semibold text-gray-800">{member.name}</h3>
            <div className="flex items-center text-amber-500">
              <StarIcon className="w-4 h-4 mr-1" />
              <span className="font-bold text-sm">{member.points} pts</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FamilyOverview;
