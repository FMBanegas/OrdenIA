
import React, { useState } from 'react';
import { FamilyMember, Task } from '../types';
import { generateTasks } from '../services/geminiService';
import { CloseIcon, SparklesIcon } from './icons';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTasks: (tasks: Omit<Task, 'id' | 'status'>[]) => void;
  familyMembers: FamilyMember[];
}

interface GeneratedTask {
  title: string;
  description: string;
  points: number;
}

const AddTaskModal: React.FC<AddTaskModalProps> = ({ isOpen, onClose, onAddTasks, familyMembers }) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedTasks, setGeneratedTasks] = useState<GeneratedTask[]>([]);
  const [selectedTasks, setSelectedTasks] = useState<number[]>([]);
  const [assignedMember, setAssignedMember] = useState<string | null>(familyMembers[0]?.id || null);

  if (!isOpen) return null;

  const handleGenerateTasks = async () => {
    if (!prompt) {
      setError('Por favor, introduce una idea para la tarea.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedTasks([]);
    setSelectedTasks([]);
    
    try {
      const tasks = await generateTasks(prompt);
      setGeneratedTasks(tasks);
      setSelectedTasks(tasks.map((_, index) => index)); // Select all by default
    } catch (e) {
      setError('Hubo un error al generar las tareas. Inténtalo de nuevo.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleTaskSelection = (index: number) => {
    setSelectedTasks(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const handleConfirmAddTasks = () => {
    const tasksToAdd = generatedTasks
      .filter((_, index) => selectedTasks.includes(index))
      .map(task => ({
        ...task,
        assignedTo: assignedMember
      }));
    onAddTasks(tasksToAdd);
    // Reset state for next time
    setPrompt('');
    setGeneratedTasks([]);
    setSelectedTasks([]);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="p-6 flex justify-between items-center border-b">
          <h2 className="text-xl font-bold text-gray-800">Añadir Tareas con IA</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          <div className="mb-4">
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-1">
              Describe una tarea o un objetivo general (ej. "limpiar la cocina")
            </label>
            <div className="flex gap-2">
              <input
                id="prompt"
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ej: Organizar el salón para la noche de cine"
                className="flex-grow p-2 border border-gray-300 rounded-md focus:ring-sky-500 focus:border-sky-500"
              />
              <button
                onClick={handleGenerateTasks}
                disabled={isLoading}
                className="px-4 py-2 bg-sky-500 text-white rounded-md hover:bg-sky-600 disabled:bg-sky-300 flex items-center justify-center min-w-[150px]"
              >
                {isLoading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <SparklesIcon className="w-5 h-5 mr-2" />
                    Generar Tareas
                  </>
                )}
              </button>
            </div>
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
          </div>

          {generatedTasks.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Tareas sugeridas por la IA:</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto p-2 bg-slate-50 rounded-md border">
                {generatedTasks.map((task, index) => (
                  <div key={index} className="flex items-center bg-white p-3 rounded-md shadow-sm">
                    <input
                      type="checkbox"
                      checked={selectedTasks.includes(index)}
                      onChange={() => handleToggleTaskSelection(index)}
                      className="h-5 w-5 rounded text-sky-600 focus:ring-sky-500 border-gray-300"
                    />
                    <div className="ml-3 flex-grow">
                      <p className="font-semibold">{task.title} <span className="font-normal text-amber-600">({task.points} pts)</span></p>
                      <p className="text-sm text-gray-500">{task.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="p-6 border-t mt-auto bg-gray-50 rounded-b-xl">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
              <label htmlFor="assignee" className="block text-sm font-medium text-gray-700 mb-1">Asignar tareas seleccionadas a:</label>
              <select
                id="assignee"
                value={assignedMember || ''}
                onChange={(e) => setAssignedMember(e.target.value)}
                className="p-2 border border-gray-300 rounded-md"
              >
                {familyMembers.map(member => (
                  <option key={member.id} value={member.id}>{member.name}</option>
                ))}
              </select>
            </div>
            <button
              onClick={handleConfirmAddTasks}
              disabled={selectedTasks.length === 0}
              className="px-6 py-3 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 disabled:bg-emerald-300 disabled:cursor-not-allowed font-semibold w-full sm:w-auto"
            >
              Añadir {selectedTasks.length} Tareas al Tablero
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddTaskModal;
