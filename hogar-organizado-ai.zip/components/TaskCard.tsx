
import React from 'react';
import { Task, FamilyMember, TaskStatus } from '../types';
import { StarIcon, PlayIcon, CheckIcon, RedoIcon } from './icons';

interface TaskCardProps {
  task: Task;
  familyMembers: FamilyMember[];
  onUpdateTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, familyMembers, onUpdateTaskStatus }) => {
  const assignedMember = familyMembers.find(member => member.id === task.assignedTo);

  const getNextAction = () => {
    switch (task.status) {
      case TaskStatus.Todo:
        return (
          <button onClick={() => onUpdateTaskStatus(task.id, TaskStatus.InProgress)} className="flex items-center text-sm px-3 py-1 bg-amber-500 text-white rounded-md hover:bg-amber-600 transition-colors">
            <PlayIcon className="w-4 h-4 mr-1" /> Empezar
          </button>
        );
      case TaskStatus.InProgress:
        return (
          <button onClick={() => onUpdateTaskStatus(task.id, TaskStatus.Done)} className="flex items-center text-sm px-3 py-1 bg-emerald-500 text-white rounded-md hover:bg-emerald-600 transition-colors">
            <CheckIcon className="w-4 h-4 mr-1" /> Completar
          </button>
        );
      case TaskStatus.Done:
         return (
          <button onClick={() => onUpdateTaskStatus(task.id, TaskStatus.Todo)} className="flex items-center text-sm px-3 py-1 bg-gray-400 text-white rounded-md hover:bg-gray-500 transition-colors">
            <RedoIcon className="w-4 h-4 mr-1" /> Rehacer
          </button>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 border-l-4 border-sky-400">
      <div className="flex justify-between items-start">
        <h4 className="font-bold text-gray-800 flex-1 pr-2">{task.title}</h4>
        <div className="flex items-center text-amber-500 font-bold">
            <StarIcon className="w-4 h-4 mr-1"/>
            <span>{task.points}</span>
        </div>
      </div>
      <p className="text-gray-600 text-sm my-2">{task.description}</p>
      <div className="flex justify-between items-center mt-3">
        {assignedMember ? (
            <div className="flex items-center">
                <img src={assignedMember.avatar} alt={assignedMember.name} className="w-8 h-8 rounded-full border-2 border-slate-200" />
                <span className="ml-2 text-sm font-medium text-gray-700">{assignedMember.name}</span>
            </div>
        ) : <div/>}
        <div>
            {getNextAction()}
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
