
import React from 'react';
import { HomeIcon } from './icons';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center">
        <HomeIcon className="h-8 w-8 text-sky-500 mr-3" />
        <h1 className="text-2xl font-bold text-gray-800 tracking-tight">Hogar Organizado AI</h1>
      </div>
    </header>
  );
};

export default Header;
