
import React from 'react';
import { Task, FamilyMember, TaskStatus } from '../types';
import TaskCard from './TaskCard';

interface TaskColumnProps {
  title: string;
  tasks: Task[];
  familyMembers: FamilyMember[];
  onUpdateTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
  status: TaskStatus;
}

const columnStyles = {
    [TaskStatus.Todo]: {
        bg: 'bg-rose-100',
        titleColor: 'text-rose-800',
        borderColor: 'border-rose-300'
    },
    [TaskStatus.InProgress]: {
        bg: 'bg-amber-100',
        titleColor: 'text-amber-800',
        borderColor: 'border-amber-300'
    },
    [TaskStatus.Done]: {
        bg: 'bg-emerald-100',
        titleColor: 'text-emerald-800',
        borderColor: 'border-emerald-300'
    }
}

const TaskColumn: React.FC<TaskColumnProps> = ({ title, tasks, familyMembers, onUpdateTaskStatus, status }) => {
  const styles = columnStyles[status];
  return (
    <div className={`${styles.bg} rounded-xl p-4 shadow-sm`}>
      <h3 className={`text-lg font-extrabold ${styles.titleColor} mb-4 pb-2 border-b-2 ${styles.borderColor}`}>{title} ({tasks.length})</h3>
      <div className="space-y-4 h-[60vh] overflow-y-auto pr-2">
        {tasks.length > 0 ? (
            tasks.map(task => (
            <TaskCard 
                key={task.id} 
                task={task} 
                familyMembers={familyMembers}
                onUpdateTaskStatus={onUpdateTaskStatus}
            />
            ))
        ) : (
            <div className="flex items-center justify-center h-full">
                <p className="text-gray-500 italic">No hay tareas aquí.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default TaskColumn;
