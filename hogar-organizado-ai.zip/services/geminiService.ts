
import { GoogleGenAI, Type } from "@google/genai";

// Assume API_KEY is set in the environment
const apiKey = process.env.API_KEY;
if (!apiKey) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey });

const taskSchema = {
    type: Type.OBJECT,
    properties: {
        title: {
            type: Type.STRING,
            description: "Un título corto y claro para la tarea (máximo 5 palabras).",
        },
        description: {
            type: Type.STRING,
            description: "Una breve descripción de la tarea (máximo 15 palabras).",
        },
        points: {
            type: Type.INTEGER,
            description: "Puntos asignados a la tarea (entre 5 y 50) según la dificultad y el tiempo requerido.",
        },
    },
    required: ["title", "description", "points"],
};

export const generateTasks = async (prompt: string): Promise<{title: string, description: string, points: number}[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Basado en el siguiente objetivo: "${prompt}", crea una lista de subtareas para una familia con niños. Sé creativo y práctico.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: taskSchema,
                },
            },
        });
        
        const responseText = response.text;
        if (!responseText) {
            throw new Error("Empty response from API");
        }
        
        const parsedResponse = JSON.parse(responseText);
        
        if (!Array.isArray(parsedResponse)) {
            throw new Error("Invalid response format from API. Expected an array.");
        }

        return parsedResponse as {title: string, description: string, points: number}[];

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to generate tasks from Gemini API.");
    }
};
