
import React from 'react';
import { Task, TaskStatus, FamilyMember } from '../types';
import TaskColumn from './TaskColumn';
import { PlusIcon } from './icons';

interface TaskBoardProps {
  tasks: Task[];
  familyMembers: FamilyMember[];
  onUpdateTaskStatus: (taskId: string, newStatus: TaskStatus) => void;
  onOpenModal: () => void;
}

const TaskBoard: React.FC<TaskBoardProps> = ({ tasks, familyMembers, onUpdateTaskStatus, onOpenModal }) => {
  const todoTasks = tasks.filter(task => task.status === TaskStatus.Todo);
  const inProgressTasks = tasks.filter(task => task.status === TaskStatus.InProgress);
  const doneTasks = tasks.filter(task => task.status === TaskStatus.Done);

  return (
    <div>
       <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-700">Tablero de Tareas</h2>
        <button
          onClick={onOpenModal}
          className="flex items-center px-4 py-2 bg-sky-500 text-white rounded-lg shadow-md hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 transition-colors"
        >
          <PlusIcon className="w-5 h-5 mr-2" />
          Añadir Tarea
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <TaskColumn 
            title="Por Hacer" 
            tasks={todoTasks} 
            familyMembers={familyMembers}
            onUpdateTaskStatus={onUpdateTaskStatus}
            status={TaskStatus.Todo}
        />
        <TaskColumn 
            title="En Progreso" 
            tasks={inProgressTasks} 
            familyMembers={familyMembers}
            onUpdateTaskStatus={onUpdateTaskStatus}
            status={TaskStatus.InProgress}
        />
        <TaskColumn 
            title="Hecho" 
            tasks={doneTasks} 
            familyMembers={familyMembers}
            onUpdateTaskStatus={onUpdateTaskStatus}
            status={TaskStatus.Done}
        />
      </div>
    </div>
  );
};

export default TaskBoard;
